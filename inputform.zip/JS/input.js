var errorNull = true, errorMail = true, errorPass = true;
var checkNull = function(){
  $(this).val($(this).val().trim());
  if ($(this).val() =="") {
    $(this).notify("Поле нужно заполнить", "error");
    $(this).addClass("errtextbox");
    errorNull = true;
  } else {
    errorNull = false;
    $(this).removeClass("errtextbox");
  }
};

$("#name").focusout(checkNull);
// $("#info").focusout(checkNull);

$("#name").keyup(function(){
  var value = $(this).val();
  if (value.length > 30){ 
    $(this).notify("Максимум 30 символов", "info");
    $(this).val(value.slice(0,29));
  }
});



$("#mail").focusout(function(){
  var value = $(this).val().trim();
  if  (value.search( /^[a-z0-9]{2,}@[a-z0-9]{1,}\.[a-z0-9]{1,}$/i) != 0) {  //Цифровые домены существуют --> разрешен их ввод
    $(this).notify("E-mail введён некорректно", "error");
    $(this).addClass("errtextbox");
    errorMail = true;
  } else { 
    $(this).removeClass("errtextbox");
    errorMail = false;
  }
});


$("#password1").focusout(function(){
  var value = $(this).val();
  if (value.length <= 5) { 
    $(this).notify("Минимум 6 символов", "error");
    $(this).addClass("errtextbox");
    errorPass = true;
  } else {
    if (value.length > 10) {
      $(this).notify("Максимум 10 символов", "error");
      $(this).addClass("errtextbox");
      errorPass = true;
    } else {
      errorPass = false;
      $(this).removeClass("errtextbox");
    }
  }
});


$("#password2").focusout(function(){
  var value = $(this).val();
  if (value != $("#password1").val()) {
    $(this).notify("Пароль не совпадает", "error");
    $(this).addClass("errtextbox");
    errorPass = true;
  } else {
    errorPass = false;
    $(this).removeClass("errtextbox");     
  }
});

$("#send").click(function(){
  if (   !(errorNull || errorMail || errorPass)) {
    $("#regForm").submit();
  } else {
    $(this).notify("Форма пустая или заполнена некорректно", "error");
  }
});