<?php

echo "<meta charset = 'utf-8'>";
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "malder71", "Malder71", "malder71");

$link->set_charset('utf8');

$link->character_set_name();
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 

// Escape user inputs for security
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$email = mysqli_real_escape_string($link, $_REQUEST['mail']);
$passwordx =  mysqli_real_escape_string($link, $_REQUEST['password1'])  ;
$comment = mysqli_real_escape_string($link, $_REQUEST['info']); 


// Attempt insert query execution
$sql = "INSERT INTO  users(name, email, passwordx,comment) VALUES ('$name', '$email', password('$passwordx'),'$comment')";
$result=mysqli_query($link, $sql);
if($result){
    echo "Запись добавлена";
    //require_once ("show.php");
} else{
    echo "ERROR: Что-то пошло не так при добавлении:   $sql. " . mysqli_error($link);
}
 
// Выведем таблицу users на экран 
printf("
<!DOCTYPE html>
<html>
<head>
         <style>
         body{background-color: lightgrey;}
         </style>
</head>
<body>  

<h3> Вывод всех пользователей  MySQL </h3>
 
<table border=\"1\" cellpadding=\"9\" cellspacing=\"0\">
 <tr style=\"border: solid 1px #000\">
  <td align=\"center\"> <b> Name </b> </td>
  <td align=\"center\"> <b> eMail</b> </td>
  <td align=\"center\"> <b> Password </b> </td>
  <td align=\"center\"> <b> Comment </b> </td>
 </tr>
");
 

$sql = "SELECT * FROM  users";
$result=mysqli_query($link, $sql);
if($result){
   // echo " прочитано ";
} else{
    echo "ERROR: Что-то пошло не так при чтении:   $sql. " . mysqli_error($link);
}


/* Цикл выведения данных  */
while($row = mysqli_fetch_array($result))
 {
    echo "<tr>";
    echo "<td>". $row ['name']."</td>";
    echo "<td>". $row ['email']."</td>";
    echo "<td>". $row ['passwordx']."</td>";
    echo "<td>". $row ['comment']."</td>";
    echo "</tr>";
}

echo("</table> \n");

printf("
</body>
</html>
");
 
// Close connection
mysqli_close($link);
?>

<a href="index.php"> Вернуться  </a>