﻿
<!DOCTYPE html>
<html>
<head>
  <meta charset='utf-8'>
  <title>Форма ввода JQ</title>

	 <script src='JS/jquery-3.3.1.min.js'></script>
	 <script src= 'JS/notify.min.js'></script>
	  
	  <link  href="CSS/style.css" rel="stylesheet" type="text/css" >
</head>
<body>

  <form action='insert.php' method='POST' id='regForm'>
 
  <lable id='title'>Форма ввода</lable>
  <table>
    <tboby>
      <tr>
        <td class='lbl'>Имя:</td>
        <td><input type='text' name='name' id='name' class='textbox'/>
      </tr>
      <tr>
        <td></td>
        <td><lable class='help'>не более 30 символов</lable></td>
      </tr>
      <tr>
        <td class='lbl'>E-mail:</td>
        <td><input type='text' name='mail' id='mail' class='textbox'/>
      </tr>
      <tr>
        <td></td>
        <td><lable class='help'>например  feedback@ukr.net </lable></td>
      </tr>
      <tr>
        <td class='lbl'>Пароль:</td>
        <td><input type='password' name='password1' id='password1' class='textbox'/>
      </tr>
      <tr>
        <td></td>
        <td><lable class='help'>от 6 до 10 символов</lable></td>
      </tr>
      <tr>
        <td class='lbl'>Подтвердить:</td>
        <td><input type='password' name='password2' id='password2' class='textbox'/>
      </tr>
      <tr>
        <td></td>
        <td><lable class='help'>должно совпадать с паролем</lable></td>
      </tr>
      <tr>
        <td class='lbl'>Комментарий:</td>
        <td><textarea maxlength='240' name='info' id='info' class='textbox'></textarea>
      </tr>
      <tr>
        <td></td>
        <td><lable class='help'>не больше 240 символов</lable></td>
      </tr>
    </tbody>
  </table>
  <input type='send' id='send' value='       Отправить форму   '/>
</form>
 <!--  скрипт валидации полей -->
<script src= 'JS/input.js'  > </script>
</body>
</html>
